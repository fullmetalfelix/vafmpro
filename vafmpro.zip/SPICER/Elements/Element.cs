﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace vafmpro.SPICER
{

    public enum ElementType
    {
        Ground = 0,
        Resistor = 1,
        Capacitor = 2,
        Inductance = 3,
        ICurrentSource = 4,
        IVoltageSource = 5,
        CCurrentSource = 6,
        CVoltageSource = 7
    };

    public abstract class eElement
    {
        public string Name;
        public int[] Nodes;
        //public ElementType Type;

        public bool isLinear = true;
        public bool isDynamic = false;
        public bool isCController = false; //if the current of this element controls something, it has to go in group 2
        public int ElementRow = -1;  //default value

        public double dV, Current;
        public double Geq, Ieq;

        public void Init(string name, int[]nodes)
        {
            Name = name;
            //Type = type;
            CopyNodes(nodes);
        }

        protected void CopyNodes(int[] nodes)
        {
            Nodes = new int[nodes.Length];
            for (int i = 0; i < Nodes.Length; i++)
                Nodes[i] = nodes[i];

        }


        //public abstractvoid Update(ref double dt);


    }


    public class eGround : eElement
    {

        public eGround(string name, int[] nodes)
        {
            Init(name, nodes);
            isLinear = true;
        }

    }

    public class eResistor : eElement
    {

        public double Resist;

        public eResistor(string name,  int[] nodes, double[] r)
        {
            Init(name, nodes);
            Resist = r[0];
            isCController = true;
        }


        //public override void Update(ref double dt)
        //{
        //    throw new NotImplementedException();
        //}
    }





}
