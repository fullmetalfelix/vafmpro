﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace vafmpro.SPICER
{
    public class eDiode : eElement
    {


        public double Isat,beta;


        public eDiode(string name, int[] nodes, double[] b)
        {
            Init(name, nodes);
            Isat = b[0];
            beta = b[1];
            isDynamic = false;
            isLinear = false;
			Geq = 0.1;
        }

    }
}
