using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace vafmpro.SPICER
{
    public class eInductor : eElement
    {

        public double L;

        public eInductor(string name, int[] nodes, double[] l)
        {
            Init(name, nodes);
            L = l[0];
            isDynamic = true; //inductors are dynamic
			
        }

    }
}