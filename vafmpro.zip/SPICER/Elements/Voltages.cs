﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using vafmpro.Circuits;


namespace vafmpro.SPICER
{

	public class eInputVoltage : eElement //TODO
    {
		public int myInputChannel;
		
		public eInputVoltage(string name, int[] nodes, double[] dv)
		{
			Init(name, nodes);
			isCController = true;
			myInputChannel = Convert.ToInt32(dv[0]);
		}
		
	}



    //independent voltage source
    public class eIVoltage : eElement
    {
       
        public eIVoltage(string name, int[] nodes, double[] dv)
        {

            Init(name, nodes);
            dV = dv[0];
            isCController = true; //this always have a current row
        }

    }


}
