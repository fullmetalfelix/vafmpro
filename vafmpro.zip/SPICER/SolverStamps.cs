using System;using vafmpro.AbsCircuits;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using vafmpro.Circuits;

namespace vafmpro.SPICER
{
    
    public partial class Network:Circuit
    {
    
    
        private void StampStaticMatrix()
        {
            //stamp all (static) elements
            #region "stamp resistors"
            foreach (eResistor r in Elements.FindAll(delegate(eElement item) { return typeof(eResistor) == item.GetType(); }))
            {
                if (r.ElementRow != -1) //if the resistor has to be in group 2
                    StampResistor(r);
                else //if its current can be eliminated
                    StampResistorNoCurrent(r);
            }
            #endregion
            #region "independent voltage sources"
            foreach (eIVoltage V in Elements.FindAll(delegate(eElement item) { return typeof(eIVoltage) == item.GetType(); }))
            {
                StampIVoltage(V);
            }
            #endregion


        }

        private void StampMatrix()
        {

            //reset the matrix
            for (int i = 0; i < mSize; i++)
            {
                MNABVector[i] = MNAStaticBVector[i];
                for (int j = 0; j < mSize; j++)
                    MNAMatrix[i, j] = MNAStaticMatrix[i,j]; //reload the static matrix
            }
			
			//stamp input voltages
			#region "inputv"
            foreach (eInputVoltage v in Elements.FindAll(delegate(eElement item) { return typeof(eInputVoltage) == item.GetType(); }))
            {
				//take dv from the channel
				//v.dV = Input[ v.myInputChannel ].Signal.Value; //NO NEED! done in update!
				StampIVoltage(v);
            }
            			
			#endregion
			
			//stamp the dynamic & nonlinear elements
			#region "linear capacitors"
            foreach (eCapacitor c in Elements.FindAll(delegate(eElement item) { return typeof(eCapacitor) == item.GetType(); }))
            {
                StampCapacitor(c);
            }
            #endregion
			#region "linear inductors"
            foreach (eInductor l in Elements.FindAll(delegate(eElement item) { return typeof(eInductor) == item.GetType(); }))
            {
                StampInductor(l);
            }
            #endregion
            #region "diode"
            foreach (eDiode d in Elements.FindAll(delegate(eElement item) { return typeof(eDiode) == item.GetType(); }))
            {
                StampDiode(d);
            }
            #endregion

        }

		#region "element stamps"
        private void StampIVoltage(eIVoltage V)
        {
            //static voltage sources go in the static matrix
            int[] nodes = V.Nodes;
            int iidx = V.ElementRow; //row index for the current of this element
            
            MNAStaticBVector[iidx] += V.dV;
            if (nodes[0] != -1) //if terminal 1 is not grounded...
            {
                MNAStaticMatrix[nodes[0], iidx] += 1;
                MNAStaticMatrix[iidx, nodes[0]] += 1;
            }
            if (nodes[1] != -1) //if terminal 2 is not grounded...
            {
                MNAStaticMatrix[nodes[1], iidx] -= 1;
                MNAStaticMatrix[iidx, nodes[1]] -= 1;
            }
        }
		private void StampIVoltage(eInputVoltage V)
        {
            //static voltage sources go in the static matrix
            int[] nodes = V.Nodes;
            int iidx = V.ElementRow; //row index for the current of this element
            
            MNABVector[iidx] += V.dV;
            if (nodes[0] != -1) //if terminal 1 is not grounded...
            {
                MNAMatrix[nodes[0], iidx] += 1;
                MNAMatrix[iidx, nodes[0]] += 1;
            }
            if (nodes[1] != -1) //if terminal 2 is not grounded...
            {
                MNAMatrix[nodes[1], iidx] -= 1;
                MNAMatrix[iidx, nodes[1]] -= 1;
            }
        }
        private void StampResistor(eResistor R) 
        {
            //resistors go in the static matrix
            int[] nodes = R.Nodes;
            int iidx = R.ElementRow; //row index for the current of this element

            MNAStaticMatrix[iidx, iidx] -= R.Resist;
            if (nodes[0] != -1) //if terminal 1 is not grounded...
            {
                MNAStaticMatrix[nodes[0], iidx] += 1;
                MNAStaticMatrix[iidx, nodes[0]] += 1;
            }
            if (nodes[1] != -1) //if terminal 2 is not grounded...
            {
                MNAStaticMatrix[nodes[1], iidx] -= 1;
                MNAStaticMatrix[iidx, nodes[1]] -= 1;
            }



        }
        private void StampResistorNoCurrent(eResistor R)
        {
            //even if they have no current, they go in the static matrix
            int[] nodes = R.Nodes;

            if (nodes[0] != -1) //if terminal 1 is not grounded...
                MNAStaticMatrix[nodes[0], nodes[0]] += 1 / R.Resist;
            if (nodes[1] != -1) //if terminal 2 is not grounded...
                MNAStaticMatrix[nodes[1], nodes[1]] += 1 / R.Resist;

            if (nodes[0] != -1 && nodes[1] != -1)
            {
                MNAStaticMatrix[nodes[0], nodes[1]] -= 1 / R.Resist;
                MNAStaticMatrix[nodes[1], nodes[0]] -= 1 / R.Resist;
            }

        }
        private void StampCapacitor(eCapacitor c)
        {
            int[] nodes = c.Nodes;
            
            if (nodes[0] != -1) //if terminal 1 is not grounded...
            {
                MNAMatrix[nodes[0], nodes[0]] += c.Geq;
                MNABVector[nodes[0]] -= c.Ieq;
            }
            if (nodes[1] != -1) //if terminal 2 is not grounded...
            {
                MNAMatrix[nodes[1], nodes[1]] += c.Geq;
                MNABVector[nodes[1]] += c.Ieq;
            }
            if (nodes[1] != -1 && nodes[1] != -1) //if both are not not grounded...
            {
                MNAMatrix[nodes[0], nodes[1]] -= c.Geq;
                MNAMatrix[nodes[1], nodes[0]] -= c.Geq;
            }

        }
        private void StampInductor(eInductor l)
        {
            int[] nodes = l.Nodes;
            
            if (nodes[0] != -1) //if terminal 1 is not grounded...
            {
                MNAMatrix[nodes[0], nodes[0]] += l.Geq;
                MNABVector[nodes[0]] -= l.Ieq;
            }
            if (nodes[1] != -1) //if terminal 2 is not grounded...
            {
                MNAMatrix[nodes[1], nodes[1]] += l.Geq;
                MNABVector[nodes[1]] += l.Ieq;
            }
            if (nodes[1] != -1 && nodes[1] != -1) //if both are not not grounded...
            {
                MNAMatrix[nodes[0], nodes[1]] -= l.Geq;
                MNAMatrix[nodes[1], nodes[0]] -= l.Geq;
            }

        }
        private void StampDiode(eDiode d)
        {
            int[] nodes = d.Nodes;       

            if (nodes[0] != -1) //if terminal 1 is not grounded...
            {
                MNAMatrix[nodes[0], nodes[0]] += d.Geq;
                MNABVector[nodes[0]] -= d.Ieq;
            }
            if (nodes[1] != -1) //if terminal 2 is not grounded...
            {
                MNAMatrix[nodes[1], nodes[1]] += d.Geq;
                MNABVector[nodes[1]] += d.Ieq;
            }
            if (nodes[1] != -1 && nodes[1] != -1) //if both are not not grounded...
            {
				MNAMatrix[nodes[0], nodes[1]] -= d.Geq;
                MNAMatrix[nodes[1], nodes[0]] -= d.Geq;
            }

        }

		#endregion
		#region "element updates"
		private void UpdateCapacitor(eCapacitor c)
		{
			//use the solution to update the companion model parameters

			//c.Current =  +c.Geq * GetDV(c.Nodes) + c.Ieq; //BE
			//c.Ieq = -GetDV(c.Nodes) * c.Geq; //BE
			
			c.dV = GetDV(c.Nodes);
		    
		    c.Current =  c.Geq * c.dV + c.Ieq;  //TR
			c.Ieq = -c.dV * c.Geq -c.Current;   //TR
			
		}
		private void UpdateInductor(eInductor l)
		{
			//use the solution to update the companion model parameters
			//l.Geq = dt/(2.0*l.L);
			l.dV = GetDV(l.Nodes);
			l.Current = l.Geq * l.dV + l.Ieq; //is the update order correct?
			l.Ieq = l.Current + l.dV * l.Geq;
		}
		private void UpdateDiode(eDiode d)
		{
			double dv = GetDV(d.Nodes);

			//updates the companion model of the diode
            d.Geq = d.Isat*d.beta*Math.Exp(dv*d.beta);
            d.Ieq = d.Current - d.Geq * dv;
            d.Current = d.Isat * (Math.Exp(dv * d.beta) - 1.0);
		}

		#endregion
    
    
    
    
    }
    
}