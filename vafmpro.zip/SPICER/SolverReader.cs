﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using vafmpro.Circuits;


namespace vafmpro.SPICER
{

    public partial class Network
    {



        //read the network description
        private bool ReadFile()
        {
            StreamReader reader = new StreamReader(FileName);
            Console.WriteLine("   Reading custom circuit...");

            //read all lines
            string line;
            string[] words;
            char[] delimiterChars = { ' ', ',', '\t' };

            int[] nodes;
            double[] param;

            if (!StringReader.FindString("<elements>", reader))
            {
                Console.WriteLine("FATAL! Elements list is missing.");
                return false;
            }
            Console.WriteLine("   Reading elements list:");


            while ((line = reader.ReadLine()) != null)
            {
                line = line.Trim();
                if (line.StartsWith("<end>"))
                    break;
                if (line.StartsWith("#") || line.Length == 0)
                    continue;

                words = StringReader.TrimWords(line.Split(delimiterChars));
                if (words.Length < 2)
                {
                    Console.WriteLine("FATAL! Insufficient parameters.");
                    return false;
                }

                #region "INPUT VOLTAGE"
                if (words[0] == "inputv")
                {
                    if (words.Length < 4)
                    {
                        Console.WriteLine("FATAL! Insufficient parameters for input voltage.");
                        return false;
                    }
                    //create an input channel
                    Input.Add(new Channel(words[1], null));

                    #region "add a voltage source"
                    nodes = new int[2];
                    if (!Int32.TryParse(words[2], out nodes[0]))
                    {
                        Console.WriteLine("FATAL! Expected initial node index.");
                        return false;
                    }
                    if (!Int32.TryParse(words[3], out nodes[1]))
                    {
                        Console.WriteLine("FATAL! Expected final node index.");
                        return false;
                    }

                    param = new double[1];
                    param[0] = InputIdx.Count;
                    #endregion
                    Elements.Add(new eInputVoltage(words[1], nodes, param));

                    //put the index of this element into the metainputs
                    InputIdx.Add(Elements.Count - 1);
                }
                #endregion
				#region "OUTPUT VOLTAGE"
                if (words[0] == "outputv")
                {
                    if (words.Length < 4)
                    {
                        Console.WriteLine("FATAL! Insufficient parameters for output voltage.");
                        return false;
                    }

                    #region "read the 2 nodes"
                    nodes = new int[3];
                    if (!Int32.TryParse(words[2], out nodes[0]))
                    {
                        Console.WriteLine("FATAL! Expected initial node index.");
                        return false;
                    }
                    if (!Int32.TryParse(words[3], out nodes[1]))
                    {
                        Console.WriteLine("FATAL! Expected final node index.");
                        return false;
                    }

                    #endregion
                    Output.Add(new Channel(words[1], this));
					OutputIdx.Add(new int[] {nodes[0],nodes[1],Output.Count-1});
                    
                }
                #endregion
				#region "OUTPUT CURRENT"
                if (words[0] == "outputi")
                {
                    if (words.Length < 3)
                    {
                        Console.WriteLine("FATAL! Insufficient parameters for output current.");
                        return false;
                    }
                    #region "read the 2 nodes"
					

                    #endregion
					//create an output channel
                    Output.Add(new Channel(words[1], this));
                    int eidx = Elements.FindIndex(delegate(eElement item) { return item.Name == words[2]; });
					OutputIIdx.Add(new int[] {eidx,Output.Count-1});
					Console.WriteLine("Output current for {0}",eidx);
                }
                #endregion
				
                #region "ground"
                if (words[0] == "ground")
                {
                    if (words.Length < 2)
                    {
                        Console.WriteLine("FATAL! Insufficient parameters for ground.");
                        return false;
                    }
                    nodes = new int[1];
                    if (!Int32.TryParse(words[1], out nodes[0]))
                    {
                        Console.WriteLine("FATAL! Expected ground node index.");
                        return false;
                    }
                    Elements.Add(new eGround("ground", nodes));
                }
                #endregion
                #region "R"
                if (words[0] == "resistor")
                {
                    if (words.Length < 5)
                    {
                        Console.WriteLine("FATAL! Insufficient parameters for resistor.");
                        return false;
                    }
                    nodes = new int[2];
                    if (!Int32.TryParse(words[2], out nodes[0]))
                    {
                        Console.WriteLine("FATAL! Expected initial node index.");
                        return false;
                    }
                    if (!Int32.TryParse(words[3], out nodes[1]))
                    {
                        Console.WriteLine("FATAL! Expected final node index.");
                        return false;
                    }

                    param = new double[1];
                    if (!double.TryParse(words[4], out param[0]))
                    {
                        Console.WriteLine("FATAL! Expected node index.");
                        return false;
                    }
                    Elements.Add(new eResistor(words[1], nodes, param));
                }

                #endregion
                #region "iV"
                if (words[0] == "ivoltage")
                {
                    if (words.Length < 5)
                    {
                        Console.WriteLine("FATAL! Insufficient parameters for voltage source.");
                        return false;
                    }
                    nodes = new int[2];
                    if (!Int32.TryParse(words[2], out nodes[0]))
                    {
                        Console.WriteLine("FATAL! Expected initial node index.");
                        return false;
                    }
                    if (!Int32.TryParse(words[3], out nodes[1]))
                    {
                        Console.WriteLine("FATAL! Expected final node index.");
                        return false;
                    }

                    param = new double[1];
                    if (!double.TryParse(words[4], out param[0]))
                    {
                        Console.WriteLine("FATAL! Expected voltage.");
                        return false;
                    }
                    Elements.Add(new eIVoltage(words[1], nodes, param));

                }

                #endregion
                #region "capacitor"
                if (words[0] == "capacitor")
                {
                    if (words.Length < 5)
                    {
                        Console.WriteLine("FATAL! Insufficient parameters for capacitor.");
                        return false;
                    }
                    nodes = new int[2];
                    if (!Int32.TryParse(words[2], out nodes[0]))
                    {
                        Console.WriteLine("FATAL! Expected initial node index.");
                        return false;
                    }
                    if (!Int32.TryParse(words[3], out nodes[1]))
                    {
                        Console.WriteLine("FATAL! Expected final node index.");
                        return false;
                    }

                    param = new double[1];
                    if (!double.TryParse(words[4], out param[0]))
                    {
                        Console.WriteLine("FATAL! Expected capacitance.");
                        return false;
                    }
                    Elements.Add(new eCapacitor(words[1], nodes, param));

                }

                #endregion
                #region "inductor"
                if (words[0] == "inductor")
                {
                    if (words.Length < 5)
                    {
                        Console.WriteLine("FATAL! Insufficient parameters for inductor.");
                        return false;
                    }
                    nodes = new int[2];
                    if (!Int32.TryParse(words[2], out nodes[0]))
                    {
                        Console.WriteLine("FATAL! Expected initial node index.");
                        return false;
                    }
                    if (!Int32.TryParse(words[3], out nodes[1]))
                    {
                        Console.WriteLine("FATAL! Expected final node index.");
                        return false;
                    }

                    param = new double[1];
                    if (!double.TryParse(words[4], out param[0]))
                    {
                        Console.WriteLine("FATAL! Expected inductance.");
                        return false;
                    }
                    Elements.Add(new eInductor(words[1], nodes, param));

                }

                #endregion
                #region "diode"
                if (words[0] == "diode")
                {
                    if (words.Length < 6)
                    {
                        Console.WriteLine("FATAL! Insufficient parameters for diode.");
                        return false;
                    }
                    nodes = new int[2];
                    if (!Int32.TryParse(words[2], out nodes[0]))
                    {
                        Console.WriteLine("FATAL! Expected initial node index.");
                        return false;
                    }
                    if (!Int32.TryParse(words[3], out nodes[1]))
                    {
                        Console.WriteLine("FATAL! Expected final node index.");
                        return false;
                    }

                    param = new double[2];
                    if (!double.TryParse(words[4], out param[0]))
                    {
                        Console.WriteLine("FATAL! Expected Isat.");
                        return false;
                    }
                    if (!double.TryParse(words[5], out param[1]))
                    {
                        Console.WriteLine("FATAL! Expected beta.");
                        return false;
                    }
                    Elements.Add(new eDiode(words[1], nodes, param));

                }

                #endregion
            }





            reader.Dispose();
            return true;
        }


    }
}