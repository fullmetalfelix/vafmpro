using System;

namespace vafmpro.AbsCircuits
{
	public abstract class absForces : Circuit
	{

		
		
		
		
		
	}
}

