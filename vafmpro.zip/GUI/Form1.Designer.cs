﻿namespace vafmpro
{
    partial class Form1
    {


        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.atirhmeticsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.constantToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aDDToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.sUBToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mULToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dIVToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aBSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.limiterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.limiterhighToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.limiterbandToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.runningAverageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logicsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nOTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aNDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.oRToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xORToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.comparisonToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.equalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.greaterEqualToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lessEqualToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.gainToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.oscillatorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lowPassFilterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.highPassFilterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.pIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pIDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ramperToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.compositeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.StatusBar = new System.Windows.Forms.StatusStrip();
            this.BarLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.StatusBar.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(0, 30);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(507, 305);
            this.panel1.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1000, 1000);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox1_Pain);
            this.pictureBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_OnMouseDown);
            this.pictureBox1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_OnMouseMove);
            this.pictureBox1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_OnMouseUp);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.addToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(568, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.toolStripSeparator1,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.Size = new System.Drawing.Size(98, 22);
            this.newToolStripMenuItem.Text = "New";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(95, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(98, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // addToolStripMenuItem
            // 
            this.addToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.atirhmeticsToolStripMenuItem,
            this.logicsToolStripMenuItem,
            this.comparisonToolStripMenuItem,
            this.toolStripSeparator2,
            this.gainToolStripMenuItem,
            this.oscillatorToolStripMenuItem,
            this.lowPassFilterToolStripMenuItem,
            this.highPassFilterToolStripMenuItem,
            this.toolStripSeparator3,
            this.pIToolStripMenuItem,
            this.pIDToolStripMenuItem,
            this.ramperToolStripMenuItem,
            this.toolStripSeparator4,
            this.compositeToolStripMenuItem});
            this.addToolStripMenuItem.Name = "addToolStripMenuItem";
            this.addToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.addToolStripMenuItem.Text = "Add...";
            // 
            // atirhmeticsToolStripMenuItem
            // 
            this.atirhmeticsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.constantToolStripMenuItem,
            this.aDDToolStripMenuItem1,
            this.sUBToolStripMenuItem,
            this.mULToolStripMenuItem,
            this.dIVToolStripMenuItem,
            this.aBSToolStripMenuItem,
            this.limiterToolStripMenuItem,
            this.limiterhighToolStripMenuItem,
            this.limiterbandToolStripMenuItem,
            this.runningAverageToolStripMenuItem});
            this.atirhmeticsToolStripMenuItem.Name = "atirhmeticsToolStripMenuItem";
            this.atirhmeticsToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.atirhmeticsToolStripMenuItem.Text = "Arithmetics";
            // 
            // constantToolStripMenuItem
            // 
            this.constantToolStripMenuItem.Name = "constantToolStripMenuItem";
            this.constantToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.constantToolStripMenuItem.Text = "Constant";
            this.constantToolStripMenuItem.Click += new System.EventHandler(this.AddConstant_Click);
            // 
            // aDDToolStripMenuItem1
            // 
            this.aDDToolStripMenuItem1.Name = "aDDToolStripMenuItem1";
            this.aDDToolStripMenuItem1.Size = new System.Drawing.Size(165, 22);
            this.aDDToolStripMenuItem1.Text = "ADD";
            this.aDDToolStripMenuItem1.Click += new System.EventHandler(this.OPPLUSToolStripMenuItem1_Click);
            // 
            // sUBToolStripMenuItem
            // 
            this.sUBToolStripMenuItem.Name = "sUBToolStripMenuItem";
            this.sUBToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.sUBToolStripMenuItem.Text = "SUB";
            this.sUBToolStripMenuItem.Click += new System.EventHandler(this.OPSUBToolStripMenuItem1_Click);
            // 
            // mULToolStripMenuItem
            // 
            this.mULToolStripMenuItem.Name = "mULToolStripMenuItem";
            this.mULToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.mULToolStripMenuItem.Text = "MUL";
            this.mULToolStripMenuItem.Click += new System.EventHandler(this.OPMULToolStripMenuItem1_Click);
            // 
            // dIVToolStripMenuItem
            // 
            this.dIVToolStripMenuItem.Name = "dIVToolStripMenuItem";
            this.dIVToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.dIVToolStripMenuItem.Text = "DIV";
            this.dIVToolStripMenuItem.Click += new System.EventHandler(this.OPDIVToolStripMenuItem1_Click);
            // 
            // aBSToolStripMenuItem
            // 
            this.aBSToolStripMenuItem.Name = "aBSToolStripMenuItem";
            this.aBSToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.aBSToolStripMenuItem.Text = "ABS";
            // 
            // limiterToolStripMenuItem
            // 
            this.limiterToolStripMenuItem.Name = "limiterToolStripMenuItem";
            this.limiterToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.limiterToolStripMenuItem.Text = "Limiter (low)";
            // 
            // limiterhighToolStripMenuItem
            // 
            this.limiterhighToolStripMenuItem.Name = "limiterhighToolStripMenuItem";
            this.limiterhighToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.limiterhighToolStripMenuItem.Text = "Limiter (high)";
            // 
            // limiterbandToolStripMenuItem
            // 
            this.limiterbandToolStripMenuItem.Name = "limiterbandToolStripMenuItem";
            this.limiterbandToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.limiterbandToolStripMenuItem.Text = "Limiter (band)";
            // 
            // runningAverageToolStripMenuItem
            // 
            this.runningAverageToolStripMenuItem.Name = "runningAverageToolStripMenuItem";
            this.runningAverageToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.runningAverageToolStripMenuItem.Text = "Running Average";
            // 
            // logicsToolStripMenuItem
            // 
            this.logicsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nOTToolStripMenuItem,
            this.aNDToolStripMenuItem,
            this.oRToolStripMenuItem,
            this.xORToolStripMenuItem});
            this.logicsToolStripMenuItem.Name = "logicsToolStripMenuItem";
            this.logicsToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.logicsToolStripMenuItem.Text = "Logics";
            // 
            // nOTToolStripMenuItem
            // 
            this.nOTToolStripMenuItem.Name = "nOTToolStripMenuItem";
            this.nOTToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.nOTToolStripMenuItem.Text = "NOT";
            this.nOTToolStripMenuItem.Click += new System.EventHandler(this.AddNOT_Click);
            // 
            // aNDToolStripMenuItem
            // 
            this.aNDToolStripMenuItem.Name = "aNDToolStripMenuItem";
            this.aNDToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.aNDToolStripMenuItem.Text = "AND";
            this.aNDToolStripMenuItem.Click += new System.EventHandler(this.AddAND_Click);
            // 
            // oRToolStripMenuItem
            // 
            this.oRToolStripMenuItem.Name = "oRToolStripMenuItem";
            this.oRToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.oRToolStripMenuItem.Text = "OR";
            this.oRToolStripMenuItem.Click += new System.EventHandler(this.AddOR_Click);
            // 
            // xORToolStripMenuItem
            // 
            this.xORToolStripMenuItem.Name = "xORToolStripMenuItem";
            this.xORToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.xORToolStripMenuItem.Text = "XOR";
            this.xORToolStripMenuItem.Click += new System.EventHandler(this.AddXOR_Click);
            // 
            // comparisonToolStripMenuItem
            // 
            this.comparisonToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.equalToolStripMenuItem,
            this.greaterEqualToolStripMenuItem,
            this.lessEqualToolStripMenuItem});
            this.comparisonToolStripMenuItem.Name = "comparisonToolStripMenuItem";
            this.comparisonToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.comparisonToolStripMenuItem.Text = "Comparison";
            // 
            // equalToolStripMenuItem
            // 
            this.equalToolStripMenuItem.Name = "equalToolStripMenuItem";
            this.equalToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.equalToolStripMenuItem.Text = "Equal";
            // 
            // greaterEqualToolStripMenuItem
            // 
            this.greaterEqualToolStripMenuItem.Name = "greaterEqualToolStripMenuItem";
            this.greaterEqualToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.greaterEqualToolStripMenuItem.Text = "Greater/Equal";
            // 
            // lessEqualToolStripMenuItem
            // 
            this.lessEqualToolStripMenuItem.Name = "lessEqualToolStripMenuItem";
            this.lessEqualToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.lessEqualToolStripMenuItem.Text = "Less/Equal";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(149, 6);
            // 
            // gainToolStripMenuItem
            // 
            this.gainToolStripMenuItem.Name = "gainToolStripMenuItem";
            this.gainToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.gainToolStripMenuItem.Text = "Gain";
            this.gainToolStripMenuItem.Click += new System.EventHandler(this.AddGain_Click);
            // 
            // oscillatorToolStripMenuItem
            // 
            this.oscillatorToolStripMenuItem.Name = "oscillatorToolStripMenuItem";
            this.oscillatorToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.oscillatorToolStripMenuItem.Text = "Oscillator";
            this.oscillatorToolStripMenuItem.Click += new System.EventHandler(this.AddOscillator_Click);
            // 
            // lowPassFilterToolStripMenuItem
            // 
            this.lowPassFilterToolStripMenuItem.Name = "lowPassFilterToolStripMenuItem";
            this.lowPassFilterToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.lowPassFilterToolStripMenuItem.Text = "LowPass Filter";
            this.lowPassFilterToolStripMenuItem.Click += new System.EventHandler(this.AddPLP_Click);
            // 
            // highPassFilterToolStripMenuItem
            // 
            this.highPassFilterToolStripMenuItem.Name = "highPassFilterToolStripMenuItem";
            this.highPassFilterToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.highPassFilterToolStripMenuItem.Text = "HighPass Filter";
            this.highPassFilterToolStripMenuItem.Click += new System.EventHandler(this.AddPHP_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(149, 6);
            // 
            // pIToolStripMenuItem
            // 
            this.pIToolStripMenuItem.Name = "pIToolStripMenuItem";
            this.pIToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.pIToolStripMenuItem.Text = "PI";
            this.pIToolStripMenuItem.Click += new System.EventHandler(this.AddPI_Click);
            // 
            // pIDToolStripMenuItem
            // 
            this.pIDToolStripMenuItem.Name = "pIDToolStripMenuItem";
            this.pIDToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.pIDToolStripMenuItem.Text = "PID";
            this.pIDToolStripMenuItem.Click += new System.EventHandler(this.AddPID_Click);
            // 
            // ramperToolStripMenuItem
            // 
            this.ramperToolStripMenuItem.Name = "ramperToolStripMenuItem";
            this.ramperToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.ramperToolStripMenuItem.Text = "Ramper";
            this.ramperToolStripMenuItem.Click += new System.EventHandler(this.AddRamper_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(149, 6);
            // 
            // compositeToolStripMenuItem
            // 
            this.compositeToolStripMenuItem.Name = "compositeToolStripMenuItem";
            this.compositeToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.compositeToolStripMenuItem.Text = "Composite";
            // 
            // StatusBar
            // 
            this.StatusBar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.BarLabel});
            this.StatusBar.Location = new System.Drawing.Point(0, 360);
            this.StatusBar.Name = "StatusBar";
            this.StatusBar.Size = new System.Drawing.Size(568, 22);
            this.StatusBar.TabIndex = 2;
            // 
            // BarLabel
            // 
            this.BarLabel.Name = "BarLabel";
            this.BarLabel.Size = new System.Drawing.Size(0, 17);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(568, 382);
            this.Controls.Add(this.StatusBar);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.StatusBar.ResumeLayout(false);
            this.StatusBar.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem atirhmeticsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aDDToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem sUBToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mULToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dIVToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aBSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logicsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nOTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aNDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem oRToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xORToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem limiterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem constantToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem limiterhighToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem limiterbandToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem runningAverageToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem comparisonToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem equalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem greaterEqualToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lessEqualToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem gainToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem oscillatorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lowPassFilterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem highPassFilterToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem pIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pIDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ramperToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem compositeToolStripMenuItem;
        private System.Windows.Forms.StatusStrip StatusBar;
        private System.Windows.Forms.ToolStripStatusLabel BarLabel;




        public System.Windows.Forms.PaintEventHandler pictureBox1_Paint { get; set; }
    }
}