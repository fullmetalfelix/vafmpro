﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using vafmpro.Circuits;

namespace vafmpro
{
    public class circuit_gui : Control
    {
        public Circuit Owner;   //owner circuit

        public Rectangle Box;   //main circuit box
        public List<Rectangle> INChBoxes,OUTChBoxes;

        private const int chsize = 10;
        private const int iconsize = 30;
        
        public Bitmap myIMG;
        public int X = 0, Y = 0;
        public int Width, Height;
        public string Text;

        //move stuff
        private int DockX, DockY;
        private bool Docked = false;

        private ToolTip Tip;
        private List<Control> chButtons;


        //creator
        public circuit_gui(Circuit owner)
        {
            Owner = owner;
            Text = Owner.GetType().ToString();
            Tip = new ToolTip();
            chButtons = new List<Control>();


            Box = new Rectangle();
            INChBoxes = new List<Rectangle>();
            OUTChBoxes = new List<Rectangle>();

            #region "control size"
            Width = owner.Width;

            int maxsizeIN = 0;
            int i = 0;
            if (Owner.Input.Count > 0) //if there are input channels
            {
                maxsizeIN += chsize * Owner.Input.Count+1;
                for (int j = 0; j < Owner.Input.Count; j++)
                {
                    INChBoxes.Add(new Rectangle(0, i * chsize, chsize, chsize));
                    //create a fake control
                    chButtons.Add(new Control("", 0, i * chsize, chsize, chsize));
                    Tip.SetToolTip(chButtons[chButtons.Count - 1], Owner.Input[j].Name);
                    i++;
                }
            }
            i = 0;
            int maxsizeOUT = 0;
            if (Owner.Output.Count > 0) //if there are output channels
            {
                maxsizeOUT += chsize * Owner.Output.Count+1;
                for (int j = 0; j < Owner.Output.Count; j++)
                {
                    
                    OUTChBoxes.Add(new Rectangle(Width - chsize, i * chsize, chsize, chsize));
                    i++;
                }
            }

            Height = Math.Max(maxsizeIN, maxsizeOUT);
            if (Height < 50)
                Height = 50;
            #endregion


            Redraw();

        }

        public void Redraw()
        {
            //create the bitmap
            myIMG = new Bitmap(Width + 1, Height);
            Box = new Rectangle(0, 0, Width, Height - 1);
            Rectangle iconBox = new Rectangle((Width - iconsize) / 2, (Height - iconsize) / 2, iconsize, iconsize);

            //draw
            Graphics g = Graphics.FromImage(myIMG);
            g.FillRectangle(Brushes.LightGray, Box);
            g.DrawRectangle(Pens.Black, Box);
            for (int i = 0; i < INChBoxes.Count; i++)
            {
                if (Owner.Input[i].Priority)
                    g.FillRectangle(Brushes.LightCyan, INChBoxes[i]);
                else
                    g.FillRectangle(Brushes.LightGoldenrodYellow, INChBoxes[i]);
                g.DrawRectangle(Pens.Black, INChBoxes[i]);
            }
            for (int i = 0; i < OUTChBoxes.Count; i++)
            {
                g.FillRectangle(Brushes.LightPink, OUTChBoxes[i]);
                g.DrawRectangle(Pens.Black, OUTChBoxes[i]);
            }

            //put a nice icon
            g.DrawImage(new Bitmap(Owner.icon), iconBox);
        }


        //determines whether the mouse is on the control
        public bool MouseON(MouseEventArgs e)
        {
            if (e.X > X && e.X < X + Width)
                if (e.Y > Y && e.Y < Y + Height)
                    return true;
            return false;
        }

        //return the text to show in the form status bar
        public string GetInfoText(MouseEventArgs e)
        {
            char[] dels={'.'};
            string result = "(" + Owner.GetType().ToString().Split(dels)[1] + ")   " + Owner.Name;

            //check if itz in a channel box
            int xr = e.X - X;
            int yr = e.Y - Y;

            for (int i = 0; i < INChBoxes.Count; i++)
            {
                if (xr > INChBoxes[i].X && xr < INChBoxes[i].X + INChBoxes[i].Width &&
                    yr > INChBoxes[i].Y && yr < INChBoxes[i].Y + INChBoxes[i].Height)
                {
                    return result + "." + Owner.Input[i].Name;
                }
            }
            for (int i = 0; i < OUTChBoxes.Count;i++)
            {
                if (xr > OUTChBoxes[i].X && xr < OUTChBoxes[i].X + OUTChBoxes[i].Width &&
                    yr > OUTChBoxes[i].Y && yr < OUTChBoxes[i].Y + OUTChBoxes[i].Height)
                {
                    return result + "." + Owner.Output[i].Name;
                }
            }
            return result;
        }



        public void DockMe(MouseEventArgs e)
        {
            DockX = e.X-X;
            DockY = e.Y-Y;
            Docked = true; //start the dock
            //Console.WriteLine("docked at {0} {1}", DockX, DockY);
        }
        public void UnDockMe()
        {
            Docked = false; //start the dock
        }


        //drag the control around
        public void MouseDrag(MouseEventArgs e)
        {

            if (e.Button == System.Windows.Forms.MouseButtons.Middle && Docked)
            {
                if (e.X - DockX > 0 && e.X - DockX < Form1.CanvasSize-Width && 
                    e.Y - DockY > 0 && e.Y - DockY < Form1.CanvasSize-Height)
                {
                    X = e.X - DockX;
                    Y = e.Y - DockY;
                }
            }

        }


        


    }
}
