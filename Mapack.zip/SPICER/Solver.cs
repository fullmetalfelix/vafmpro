﻿using System;using vafmpro.AbsCircuits;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using vafmpro.Circuits;

namespace vafmpro.SPICER
{
    
    public partial class Network:Circuit
    {
        private string FileName; //file where the network is defined
        private List<eElement> Elements; //list of elements in the network

        private int nNodes,nCurrents, mSize;
        private List<int> GNodes; //nodes that are put to ground

        private double[,] MNAMatrix,MNAStaticMatrix; //static matrix contains resistors and static stuff
        private double[] MNABVector,MNAStaticBVector, MNASolution, MNASolutionO;
        private int[] MNAidx;

        private bool isDynamic = false, isNonLinear = false;

		private double dt;
		
        public List<int> InputIdx; //InputIdx[i] is the index of the voltage source connected to the i-th input
        public List<int[]> OutputIdx;//OutputIdx[i][0,1,2] {node0,node1,outputch}
		public List<int[]> OutputIIdx; //OutputIIdx[i][0,1] {elem index,outputch}
		
		public int MaxIterations = 100;
		public double Tolerance = 0.001;

		public Network(string file,string name, double deltat) //constructor
        {
            Init(name);
			dt=deltat;
            FileName = file;
            Elements = new List<eElement>();
            GNodes = new List<int>();

            InputIdx = new List<int>();
            OutputIdx = new List<int[]>();
			OutputIIdx=new List<int[]>();

        }

        public bool Initialize()
        {

            if (!ReadFile())
                return false;

            InitMatrix();

            return true;
        }
		

        private void InitMatrix()
        {

            #region "node relabel"
            //first find all the grounded nodes
            for (int i = 0; i < Elements.Count; i++)
                if ( typeof(eGround) == Elements[i].GetType() )
                    GNodes.Add(Elements[i].Nodes[0]);
			//GNodes = GNodes.Distinct().ToList();   //remove the dupplicates
			List<int> GNodesNODUB = new List<int>();
			for(int i=0;i<GNodes.Count;i++)
			{
				if(!GNodesNODUB.Contains(GNodes[i]))
					GNodesNODUB.Add(GNodes[i]);
				
				//Console.WriteLine("item {0}",GNodes[i].ToString());
				
			}
			GNodes=GNodesNODUB;
			
            //now all the elements' nodes that are grounded get a value -1
            for (int i = 0; i < Elements.Count; i++)
                for (int j = 0; j < Elements[i].Nodes.Length; j++)
                    if (GNodes.Contains(Elements[i].Nodes[j]))
                        Elements[i].Nodes[j] = -1;
            for(int i = 0; i < OutputIdx.Count; i++) //purge the output voltage reader too
				for (int j = 0; j<2; j++)
					if (GNodes.Contains(OutputIdx[i][j]))
						OutputIdx[i][j] = -1;
						
            //now all the grounded nodes have a -1 value.


            //count  and reorder the nodes: this just finds the maximum!
            List<int> nodeidx = new List<int>();

            for (int i = 0; i < Elements.Count; i++)
                for (int j = 0; j < Elements[i].Nodes.Length; j++)
                    if (Elements[i].Nodes[j] != -1)
                        nodeidx.Add(Elements[i].Nodes[j]);
			
			List<int> nodeidxNODUB = new List<int>();
			for(int i=0;i<nodeidx.Count;i++)
			{
				if(!nodeidxNODUB.Contains(nodeidx[i]))
					nodeidxNODUB.Add(nodeidx[i]);
			}
			nodeidx = nodeidxNODUB;
			
			for(int i=0;i<nodeidxNODUB.Count;i++)
				Console.WriteLine("nodeidx {0} {1}",i,nodeidx[i]);
			
            //nodeidx = nodeidx.Distinct().ToList();
            nNodes = nodeidx.Count;  //this is the effective number of nodes
            for (int k = 0; k < nodeidx.Count; k++) //relabel
            {
                for (int i = 0; i < Elements.Count; i++)
                    for (int j = 0; j < Elements[i].Nodes.Length; j++)
                        if (Elements[i].Nodes[j] == nodeidx[k])
                            Elements[i].Nodes[j] = k;
				for(int i = 0; i < OutputIdx.Count; i++) //relabel the output voltage reader too
					for (int j = 0; j<2; j++)
						if (OutputIdx[i][j] == nodeidx[k])
							OutputIdx[i][j] = k;
            }
            #endregion
            //now all the nodes are labeld with running index, with no gaps!
            //nNodes has the right number of nodes not grounded

            //find the right amount of currents to retain
            nCurrents=0;
            for (int i = 0; i < Elements.Count; i++)
                if (Elements[i].isCController)
                {
                    Elements[i].ElementRow = nNodes + nCurrents; //sets the row index for the current of this element
                    nCurrents++;
                }

            mSize = nNodes + nCurrents; // and here is the total matrix size

            isDynamic = CheckDynamic();
            isNonLinear = CheckNONLinear();


            MNAMatrix = new double[mSize, mSize];
            MNAStaticMatrix = new double[mSize, mSize];

            MNABVector = new double[mSize];
            MNAStaticBVector = new double[mSize];

            MNASolution = new double[mSize];
            MNASolutionO = new double[mSize];
            MNAidx=new int[mSize];

			//set the Geq for capacitors
			foreach (eCapacitor c in Elements.FindAll(delegate(eElement item) { return typeof(eCapacitor) == item.GetType(); }))
			{
				c.Geq = 2.0*c.C/dt;
				c.Current=0;
			}
			foreach (eInductor l in Elements.FindAll(delegate(eElement item) { return typeof(eInductor) == item.GetType(); }))
			{
				l.Geq = dt/(2.0*l.L);
			}
            //stamp the static elements in the static matrix
            StampStaticMatrix();


            //DebugPrintVector(MNABVector);

            //DebugPrintVector(MNASolution);
        }


        public override void Update(ref double dt)
        {
            
            //first read all input channel voltages
            for (int i = 0; i < Input.Count; i++)
                Elements[InputIdx[i]].dV = Input[i].Signal.Value;

            //solve the MNA problem
            #region "solve the system"
			double tolcheck = 0;
			if(isNonLinear)
			{
				for (int i = 0; i < MaxIterations; i++)
				{
					StampMatrix(); //stamp the dynamic & nonlinear parts
					//Console.WriteLine("\ni={0} Ieq={1} DV={2}", ((eCapacitor)Elements[2]).Current.ToString(), ((eCapacitor)Elements[2]).Ieq.ToString(),GetDV(Elements[2].Nodes));
					//DebugPrint();
					SolveMatrix(isNonLinear);
					//if (i % 100 == 0)
					//DebugPrintVector(MNASolution);
					
					//check if the solution changed more than tolerance
					for(int j=0;j<mSize;j++)
					{
						tolcheck+= (MNASolution[j]-MNASolutionO[j])*(MNASolution[j]-MNASolutionO[j]);
						MNASolutionO[j] = MNASolution[j];
					}
					tolcheck /= mSize;
					if(tolcheck < Tolerance*Tolerance)
					{
						//Console.WriteLine("SPICE converged! {0}",i);
						break;
					}
					
				}
			}

			//now that the nonlinear parts are rhapsoned, update the capacitors and do the step
			StampMatrix();
			SolveMatrix(false);
			
			#endregion
			
			//DebugPrint();
			//Console.WriteLine("---------------{0}",Elements[3].dV);
            DebugPrintVector(MNASolution);
			//Console.WriteLine("---------------");
			
			
            //send the output
			for(int i=0;i<OutputIdx.Count;i++)  //voltage output
				Output[OutputIdx[i][2]].Signal.Value = GetDV(OutputIdx[i]);
			for(int i=0;i<OutputIIdx.Count;i++)
				Output[OutputIIdx[i][1]].Signal.Value = Elements[OutputIIdx[i][0]].Current;

        }


        private double GetDV(int[] nodes)
        {
            double result = 0;
            if (nodes[1] != -1) result = MNASolution[nodes[1]];
            if (nodes[0] != -1) result -= MNASolution[nodes[0]];

			return -result;
        }


		
		
		private void SolveMatrix(bool NewtonRhapson)
        {

            LUDecompose(ref MNAMatrix, ref MNAidx);
            Solve(ref MNABVector, ref MNASolution, MNAidx, MNAMatrix);

			//if we are not doing a newton-rhapson linearization...
			if(!NewtonRhapson)
			{
				//update the companion model of capacitors
				foreach (eCapacitor c in Elements.FindAll(delegate(eElement item) { return typeof(eCapacitor) == item.GetType(); }))
					UpdateCapacitor(c);
				foreach (eInductor l in Elements.FindAll(delegate(eElement item) { return typeof(eInductor) == item.GetType(); }))
					UpdateInductor(l);

			}
			
			//update companion model for diodes
			foreach (eDiode d in Elements.FindAll(delegate(eElement item) { return typeof(eDiode) == item.GetType(); }))
				UpdateDiode(d);
				

        }


        //check if there are dynamic elements
        private bool CheckDynamic()
        {
            for (int i = 0; i < Elements.Count; i++)
                if (Elements[i].isDynamic)
                    return true;
            return false;
        }
        private bool CheckNONLinear()
        {
            for (int i = 0; i < Elements.Count; i++)
                if (!Elements[i].isLinear)
                    return true;
            return false;
        }

        #region "LU & solver"
        private void LUDecompose(ref double[,] lu, ref int[] indx)
        {

            int i, imax = 0, j, k, n = lu.GetLength(0);

            double big, temp;

            double[] vv = new double[n];

            //preChecks

            if (lu.GetLength(0) != lu.GetLength(1) || lu.GetLength(0) != indx.Length)

                throw new Exception("matrix dimension problem only use square matrices");

            //for each row find the absolute value of the greatest cell and store in vv

            for (i = 0; i < n; i++)
            {

                big = 0.0;

                for (j = 0; j < n; j++)

                    if ((temp = Math.Abs(lu[i, j])) > big) big = temp;

                if (big == 0.0)

                    throw new Exception("singular matrix");



                vv[i] = 1.0 / big;//calculate scaling and save

            }

            //k is for colums start with the left look for the columns under the diagonal for the biggest value want to move the largest over diagonal

            for (k = 0; k < n; k++)//find the largest pivot element 
            {

                big = 0.0;

                for (i = k; i < n; i++)
                {

                    temp = vv[i] * Math.Abs(lu[i, k]);

                    if (temp > big)
                    {

                        big = temp;

                        imax = i;

                    }

                }



                if (k != imax)//do we need a row change 
                {

                    for (j = 0; j < n; j++)// counter for the colums
                    {

                        temp = lu[imax, j];// change the rows

                        lu[imax, j] = lu[k, j];

                        lu[k, j] = temp;

                    }

                    vv[imax] = vv[k];

                }

                indx[k] = imax;



                for (i = k + 1; i < n; i++)
                {

                    temp = lu[i, k] /= lu[k, k];//divide pilot element

                    for (j = k + 1; j < n; j++)

                        lu[i, j] -= temp * lu[k, j];

                }

            }



        }
        private void Solve(ref double[] b, ref double[] x, int[] indx, double[,] lu)
        {

            if (b.Length != lu.GetLength(0) || x.Length != lu.GetLength(0))

                throw new Exception("vector dimension problem");



            int n = lu.GetLength(0);

            int i, ii = 0, ip, j;

            double sum = 0;

            for (i = 0; i < n; i++) x[i] = b[i];

            for (i = 0; i < n; i++)
            {

                ip = indx[i];

                sum = x[ip];

                x[ip] = x[i];

                if (ii != 0)

                    for (j = ii - 1; j < i; j++) sum -= lu[i, j] * x[j];

                else if (sum != 0.0)

                    ii = i + 1;

                x[i] = sum;

            }

            for (i = n - 1; i >= 0; i--)
            {

                sum = x[i];

                for (j = i + 1; j < n; j++) sum -= lu[i, j] * x[j];

                x[i] = sum / lu[i, i];

            }

        }
        #endregion

        private void DebugPrintVector(double[] vect)
        {

            //Console.WriteLine("--- MNA MATRIX ---");
            for (int i = 0; i < mSize; i++)
                Console.Write("{0,8: #.0000}", vect[i]);
            Console.WriteLine("ASDASD");
        }
        private void DebugPrint()
        {

            Console.WriteLine("--- MNA MATRIX ---");
            for (int i = 0; i < mSize; i++)
            {
                for (int j = 0; j < mSize; j++)
                    Console.Write("{0,8: #.00} ", MNAMatrix[i, j]);
                Console.Write("    {0,8: #.00}\n", MNABVector[i]);
            }
            Console.WriteLine("------------------");
        }
        private void DebugPrint(double[,] mat)
        {

            Console.WriteLine("--- MATRIX ---");
            for (int i = 0; i < mSize; i++)
            {
                for (int j = 0; j < mSize; j++)
                    Console.Write("{0,8: #.00} ", mat[i, j]);
                Console.Write("\n");
            }
            Console.WriteLine("------------------");


        }




        




    }
}
