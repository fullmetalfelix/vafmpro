﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace vafmpro.SPICER
{
    public class eCapacitor : eElement
    {

        public double C;

        public eCapacitor(string name, int[] nodes, double[] c)
        {
            Init(name, nodes);
            C = c[0];
            isDynamic = true; //capacitors are dynamic
			Geq = 0;
        }

    }
}
