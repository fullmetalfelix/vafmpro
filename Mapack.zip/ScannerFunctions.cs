﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace vafmpro.Circuits
{


    public partial class Scanner : Circuit
    {
        //here are the functions that can be scripted in the scanner
        //each one of these returns true if the action is finished!


    }




}