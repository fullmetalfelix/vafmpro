using System;using vafmpro.AbsCircuits;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;


namespace vafmpro.Circuits
{
	// 4D force field quadri-linear interpolator - F(x,y,z,v)
	/*
	public class IntrpLin4D : ForceInterpolator4D
	{
		
		
		
		
		
		
		
		
		
		
		
		
	}*/
	
}