﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using vafmpro.Circuits;

namespace vafmpro
{
    public partial class Form1 : Form
    {
        public List<Circuit> Circuits;  //list of circuits

        public static int CanvasSize = 2000;
        private Bitmap Canvas = new Bitmap(CanvasSize, CanvasSize);
        private Graphics Grapher;

        private bool Docked = false;
        private circuit_gui DockedItem = null;

        

        public Form1()
        {
            InitializeComponent();
            Circuits = new List<Circuit>();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.DoubleBuffered = true;
            Grapher = Graphics.FromImage(Canvas);
            pictureBox1.Height = CanvasSize;
            pictureBox1.Width = CanvasSize;
        }

        

        protected override void OnResize(EventArgs e)
        {
            panel1.Width = this.Width-16;
            panel1.Height = this.Height - 68-22;


        }

        protected void pictureBox1_Pain(object sender, PaintEventArgs e)
        {

            e.Graphics.DrawImage(Canvas, 0, 0);

            e.Graphics.FillRectangle(Brushes.White, e.ClipRectangle); //background

            //draw the circuits
            for (int i = 0; i < Circuits.Count; i++)
            {
                e.Graphics.DrawImageUnscaled(Circuits[i].myGUI.myIMG, Circuits[i].myGUI.X, Circuits[i].myGUI.Y);


            }



        }

        //protected override void OnPaintBackground(PaintEventArgs e){ }

        protected void pictureBox1_OnMouseDown(object sender, MouseEventArgs e)
        {

            //check if we are on a circuit
            for (int i = 0; i < Circuits.Count; i++)
            { 
                if (Circuits[i].myGUI.MouseON(e) && e.Button == System.Windows.Forms.MouseButtons.Middle) //if itz on a circuit and middle button is down
                {   //move the poor fucker
                    if (!Docked) // if nothing is docked,
                    {
                        Docked = true; //dock the mouse
                        Circuits[i].myGUI.DockMe(e); //dock the circuit
                        DockedItem = Circuits[i].myGUI;
                    }
                    break;
                }

            }

        }
        protected void pictureBox1_OnMouseUp(object sender, MouseEventArgs e)
        {
            if (Docked) //if docked, undock
            {
                Docked = false;
                DockedItem.UnDockMe(); // undock the circuit
                DockedItem = null;
            }

        }
        protected void pictureBox1_OnMouseMove(object sender, MouseEventArgs e)
        {
            base.OnMouseMove(e);


            //if we have something docked move it
            if (Docked)
            {
                DockedItem.MouseDrag(e);
                pictureBox1.Invalidate();
                return;
            }

            //check if we are on a circuit
            for (int i = 0; i < Circuits.Count; i++)
            {

                if (Circuits[i].myGUI.MouseON(e))
                {
                    this.BarLabel.Text = Circuits[i].myGUI.GetInfoText(e);
                    Circuits[i].myGUI.MouseDrag(e);
                    pictureBox1.Invalidate();
                    return;
                }

            }

            this.BarLabel.Text = ""; //clear the text if not on a circuit


        }
        protected void pictureBox1_OnMouseRelease(object sender, MouseEventArgs e)
        {


        }

        //menu items clicks!
        #region "ADD menu"

        private void InitLastGui()
        {
            Circuits[Circuits.Count - 1].GUIInit();  //initialize the gui!
            pictureBox1.Invalidate();
        }

        private void AddConstant_Click(object sender, EventArgs e)
        {
            Circuits.Add(new Constant("NONAME!", 0));
            InitLastGui();
        }
        private void AddOscillator_Click(object sender, EventArgs e)
        {
            Circuits.Add(new Oscillator("NONAME!"));
            InitLastGui();
        }

        #region "Operators"
        private void OPPLUSToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Circuits.Add(new OpPlus("NONAME!"));
            InitLastGui();
        }
        private void OPSUBToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Circuits.Add(new OpMinus("NONAME!"));
            InitLastGui();
        }
        private void OPMULToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Circuits.Add(new OpMult("NONAME!"));
            InitLastGui();
        }
        private void OPDIVToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Circuits.Add(new OpDivd("NONAME!"));
            InitLastGui();
        }


        #endregion
        #region "logics"
        private void AddNOT_Click(object sender, EventArgs e)
        {
            Circuits.Add(new OpNOT("NONAME!"));
            InitLastGui();
        }
        private void AddAND_Click(object sender, EventArgs e)
        {
            Circuits.Add(new OpAND("NONAME!"));
            InitLastGui();
        }
        private void AddOR_Click(object sender, EventArgs e)
        {
            Circuits.Add(new OpOR("NONAME!"));
            InitLastGui();
        }
        private void AddXOR_Click(object sender, EventArgs e)
        {
            Circuits.Add(new OpXOR("NONAME!"));
            InitLastGui();
        }
        #endregion


        private void AddGain_Click(object sender, EventArgs e)
        {
            Circuits.Add(new Gain("NONAME!",0));
            InitLastGui();
        }
        private void AddRamper_Click(object sender, EventArgs e)
        {
            Circuits.Add(new Ramper("NONAME!",0,0,0));
            InitLastGui();
        }

        #region "filter"
        private void AddPLP_Click(object sender, EventArgs e)
        {
            Circuits.Add(new PLP("NONAME!", 1, 1));
            InitLastGui();
        }
        private void AddPHP_Click(object sender, EventArgs e)
        {
            Circuits.Add(new PHP("NONAME!", 1, 1));
            InitLastGui();
        }
        #endregion
        #region "PI"
        private void AddPI_Click(object sender, EventArgs e)
        {
            Circuits.Add(new PI("NONAME!"));
            InitLastGui();
        }
        private void AddPID_Click(object sender, EventArgs e)
        {
            Circuits.Add(new PID("NONAME!"));
            InitLastGui();
        }
        #endregion

        #endregion










    }
}
